export interface IResponse {
  id?: string;
  userId?: string;
  title?: string;
  body?: string;
}
